############### Env ###############
# 환경변수 설정
class Env:
    def __init__(self):
        self.readDataFile = './data/scores_korean.txt'         # 불러올 파일명 지정
        self.saveDataFile = './data/below_average_korean.txt'   # 저장할 파일명 지정 
######################################  