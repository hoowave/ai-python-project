############### Env ###############
# 환경변수 설정
class Env:
    def __init__(self):
        self.saveDataFile = './log/ip_analysis.csv'   # 저장할 파일명 지정 
######################################  