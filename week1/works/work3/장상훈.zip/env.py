############### Env ###############
# 환경변수 설정
class Env:
    def __init__(self):
        self.monitorDirectory = './monitor_directory'   # 감시 대상 디렉터리
        self.interval = 0.3                             # 감지 루핑 시간
######################################  