############### Env ###############
# 환경변수 설정
class Env:
    def __init__(self):
        self.fontFamily = 'Malgun Gothic'       # Font Family 설정
        self.dataPath = './data/'               # 데이터 파일 경로
        self.dataName = 'mall_customers.csv'          # 데이터 파일 이름